## Computer Graphics 
## Exercise 02 - Lighting
## Date: 07.10.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

* Diffuse and Specular contributions to the scene was easy. 
* Also the shadow contribution was doable.

* Then the reflection contribution was already tricky and we needed some time to implement it.

* All result images are stored in the "results" folder.