## Computer Graphics 
## Exercise 04 - Raytracer Extensions and OpenGL “Hello World”
## Date: 23.10.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

As this assingment is ungraded and we have a huge workload, you will only see the expected output of the OpenGL "Hello World" in the png file.