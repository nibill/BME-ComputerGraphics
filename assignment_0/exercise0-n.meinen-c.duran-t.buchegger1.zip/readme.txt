## Computer Graphics 
## Exercise 00
## Date: 24.09.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

Changing solid_color.sce so the background would be pink. No problems encountered in the setup for the IDE for all team memebers.