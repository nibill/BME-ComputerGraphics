## Computer Graphics 
## Exercise 08 - Lindenmayer Systems
## Date: 20.11.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

• 25%: Grammar expansion (Tasks, 1.1, 1.2, and 1.3; 10%, 10%, and 5% respectively)
    Give the found symbol back, or the old.
    Replace all given on the rules.
    Expand the string on each iteration.
• 30%: Drawing (Task 2)
    Depending on the char, we rotate. For that we prepare the rot matrix.
• 30%: Reverse engineering (Task 3; 7% for the first 3 systems, 9% for the last)
    Try and error, you need to have some kind of feeling.
• 15%: Stochastic systems (Task 4)
    Simillar to task 1, but we use the dice as mentioned.

