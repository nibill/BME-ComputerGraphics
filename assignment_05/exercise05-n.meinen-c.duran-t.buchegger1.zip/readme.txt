## Computer Graphics 
## Exercise 04 - Transformations and Viewing
## Date: 28.10.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

• Placing the objects in the scene: 30%
    Handling the origin from planets to sun and from the moon to earth.
• Placing the eye in the scene: 30%
    We differ between the space ship and the planets. The center of the camera is different.
• Rendering textured objects: 30%
    Inspiration from the sun rendering, but use color_shader.
• Responding to keyboard events: 10%
    Simple case/switch statement.