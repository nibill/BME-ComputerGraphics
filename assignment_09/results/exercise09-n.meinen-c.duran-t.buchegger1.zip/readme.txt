## Computer Graphics 
## Exercise 09 - Perlin Noise
## Date: 27.11.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

• 15%: 1D Perlin noise (Task 1.1)
    Get upper and lower from grad, get gradient by random hash, evaluate the corners, then mix the weight from the blending weight.
• 35%: 2D Perlin noise (Task 2.1)
    Extend the 1D as instructed
• 15%: fBm and Turbulence (Tasks 1.2, 2.2, and 2.3; 5% each)
    implementing as documented in the task
• 15%: Textures (Task 3; 5% each)
    it is important to check the water level
• 20%: Terrain (Task 4; Terrain mesh construction: 15%, shading: 5%)
    apply the hight map and again, the water levels.