## Computer Graphics 
## Exercise 01
## Date: 24.09.2020
## Team Members: T.Buchegger, C.Duran, N.Meinen
##############################################################################################################

* implementation of plane intersection was easy.
* the theory exercise was doable.

* the ray cylinder interpretation was a bit difficult. First the correct implementation from the derivation, than the correct implementation for the quadratic formula. In the end also the correct evaluation of the result.
* in the first approach the color of the normals did not look the same as in the expected result. But then flipping the normals if they are bigger than 90° did the trick. The ray was therefore not reflecting on the outside.
